# marol_model > 2024-04-23 11:07pm
https://universe.roboflow.com/computervision-of3yl/marol_model

Provided by a Roboflow user
License: CC BY 4.0

